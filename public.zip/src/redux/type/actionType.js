
/**
 * User login action type
 * We have three action LOGIN_SUCCESS, LOGOUT, LOGIN_FAILD
 */
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGOUT = "LOGOUT";
export const LOGIN_FAILD = "LOGIN_FAILD";


/**
 * 
 */

export const ADD_SLOT = "ADD_SLOT";
export const DELETE_SLOT = "DELETE_SLOT";