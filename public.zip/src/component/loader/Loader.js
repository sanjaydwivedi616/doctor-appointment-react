import React from 'react'

const Loader = () => {
    return (
        <div>
            <p className="text-center">Loadding....</p>
        </div>
    )
}

export default Loader;