import React from 'react'

function Footer() {
    return (
        <p className="footer">&#169; copyright HCL 2021</p>
    )
}

export default Footer;