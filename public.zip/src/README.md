Technology used
--------javascript-------
1. ES6 and above.
    Arrow function.
    Destructuring (object, Array).
    Conditional rendering in react.
    Map(), filter(),

--------React-------

2. React 17.0.1.
3. React Hook (useState, useEffect).
4. Functional component.
5. Presentational components.
6. Container component.
7. Control components.
8. Axios for api call.
9. Lazy Loading.
10. React Router Dom (Routing).
11. Redux for global stor.
12. Redux Thank for handel the synchronous action.
13. formik for form.


--------Styling-------

14. material UI.
15. Yap for form validation.
16. Bootstrap for styling.