import { act } from "react-dom/cjs/react-dom-test-utils.production.min";
import ListData from "../../../component/ListData";

/*  describe('When Available Slot List page is render', () => {
    it("Render doctor list", () => {
        const doctorList = [{
            id:1,
            name: "rohit",
            address: "123, btn bangalore"
        }];

        jest.spyOn(api, 'getDataApi').mockImplementation(() =>
            Promise.resolve({
                json: () => Promise.resolve(doctorList)
            })
        );

        act( () => {
            render(<ListData />, container);
        });

    })
}) */

